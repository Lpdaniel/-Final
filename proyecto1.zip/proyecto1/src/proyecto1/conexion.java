package proyecto1;

import com.mysql.jdbc.Connection;
import static proyecto1.conexion.con;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

public class conexion {

    
    public static Connection con;
    
    private static final String driver = "com.mysql.jdbc.Driver";
    private static final String user = "root";
    private static final String pass = "";
    private static final String url = "jdbc:mysql://localhost/conexion";
    
    public Connection conectar(){
    
    con = null;
    try{
    con = (Connection) DriverManager.getConnection(url,user,pass);
    if(con!=null){
    }
    
    
    }catch(SQLException e)
    {
    JOptionPane.showMessageDialog(null, "Error" + e.toString());
    }
    return con;
    
    
    }
}