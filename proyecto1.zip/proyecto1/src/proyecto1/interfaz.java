package proyecto1;

//Librerias que estamos utilizando
import config.conexion;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
//Classe extendida de java.swing
public class interfaz extends javax.swing.JFrame {

    conexion conl = new conexion();
    Connection conet;
    DefaultTableModel modelo;
    Statement st;
    ResultSet rs;
    int idc;

    
    public interfaz() {
        initComponents();
        setLocationRelativeTo(null);
        consultar();
    }

    /**
    
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jPasswordField1 = new javax.swing.JPasswordField();
        txtnombre = new javax.swing.JTextField();
        txtnumero = new javax.swing.JTextField();
        txtTiempo = new javax.swing.JTextField();
        txtGanancias = new javax.swing.JTextField();
        comboequipo = new javax.swing.JComboBox<>();
        btnRegistrar = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnMostrar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        jLabel2.setText("jLabel2");

        jPasswordField1.setText("jPasswordField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtnombre.setBackground(java.awt.Color.black);
        txtnombre.setFont(new java.awt.Font("Century Schoolbook", 1, 18)); // NOI18N
        txtnombre.setForeground(java.awt.Color.white);
        txtnombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtnombre.setToolTipText("");
        txtnombre.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, java.awt.Color.white), "Nombre y Apellido", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Century Schoolbook", 1, 14), java.awt.Color.white)); // NOI18N
        getContentPane().add(txtnombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 110, 280, 70));

        txtnumero.setBackground(java.awt.Color.black);
        txtnumero.setFont(new java.awt.Font("Century Schoolbook", 1, 18)); // NOI18N
        txtnumero.setForeground(java.awt.Color.white);
        txtnumero.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtnumero.setToolTipText("");
        txtnumero.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, java.awt.Color.white), "N*", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Century Schoolbook", 1, 14), java.awt.Color.white)); // NOI18N
        getContentPane().add(txtnumero, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 110, 80, 70));

        txtTiempo.setBackground(java.awt.Color.black);
        txtTiempo.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        txtTiempo.setForeground(java.awt.Color.white);
        txtTiempo.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTiempo.setToolTipText("");
        txtTiempo.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, java.awt.Color.white), "Tiempo en la NBA", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Century Schoolbook", 1, 14), java.awt.Color.white)); // NOI18N
        getContentPane().add(txtTiempo, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 190, 370, 70));

        txtGanancias.setBackground(java.awt.Color.black);
        txtGanancias.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        txtGanancias.setForeground(java.awt.Color.white);
        txtGanancias.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtGanancias.setToolTipText("");
        txtGanancias.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, java.awt.Color.white), "Ganancias ", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Century Schoolbook", 1, 18), java.awt.Color.white)); // NOI18N
        txtGanancias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGananciasActionPerformed(evt);
            }
        });
        getContentPane().add(txtGanancias, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 270, 370, 70));

        comboequipo.setBackground(java.awt.Color.black);
        comboequipo.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        comboequipo.setForeground(java.awt.Color.white);
        comboequipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Los Angeles Lakers ", "Golden State Warriors", "Minnesota Timberwolves", "Miami Heat", "Dallas Mavericks", "Boston Celtics", "Chicago" }));
        comboequipo.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Equipo", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Century Schoolbook", 1, 14), java.awt.Color.white)); // NOI18N
        comboequipo.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().add(comboequipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 360, 260, 80));

        btnRegistrar.setBackground(java.awt.Color.black);
        btnRegistrar.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        btnRegistrar.setForeground(java.awt.Color.white);
        btnRegistrar.setText("Registrar");
        btnRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarActionPerformed(evt);
            }
        });
        getContentPane().add(btnRegistrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 480, 120, 40));

        btnBuscar.setBackground(java.awt.Color.black);
        btnBuscar.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        btnBuscar.setForeground(java.awt.Color.white);
        btnBuscar.setText("Buscar");
        getContentPane().add(btnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 540, 120, 40));

        btnActualizar.setBackground(java.awt.Color.black);
        btnActualizar.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        btnActualizar.setForeground(java.awt.Color.white);
        btnActualizar.setText("Actualizar");
        getContentPane().add(btnActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 480, 120, 40));

        btnEliminar.setBackground(java.awt.Color.black);
        btnEliminar.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        btnEliminar.setForeground(java.awt.Color.white);
        btnEliminar.setText("Eliminar");
        getContentPane().add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 480, 120, 40));

        btnMostrar.setBackground(java.awt.Color.black);
        btnMostrar.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        btnMostrar.setForeground(java.awt.Color.white);
        btnMostrar.setText("Mostrar");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });
        getContentPane().add(btnMostrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 540, 120, 40));

        Tabla.setBackground(java.awt.Color.darkGray);
        Tabla.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        Tabla.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        Tabla.setForeground(java.awt.Color.white);
        Tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Numero", "Nombre", "Tiempo", "Ganancias", "Equipo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        Tabla.setAutoscrolls(false);
        Tabla.setEditingColumn(100);
        jScrollPane1.setViewportView(Tabla);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 100, 550, 420));

        jLabel1.setBackground(java.awt.Color.black);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto1/basket.jpg"))); // NOI18N
        jLabel1.setToolTipText("");
        jLabel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 255, 255)), "INTEGRANTES DE LA NBA", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Century Schoolbook", 1, 24), java.awt.Color.white)); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1160, 770));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtGananciasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGananciasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtGananciasActionPerformed

    private void btnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarActionPerformed
        //GEN-FIRST:event_btnAgregarActionPerformed
        String insertarSQL = "INSERT INTO jugadores (NUMERO, NOMBRE_Y_APELLIDO, TIEMPO_NBA, GANANCIAS, EQUIPO) VALUES (?,?,?,?,?)";
        try {
            PreparedStatement ps;
            ps = (PreparedStatement) conet.prepareStatement(insertarSQL);
            ps.setString(1, txtnumero.getText());
            ps.setString(2, txtnombre.getText());
            ps.setString(3, txtTiempo.getText());
            ps.setString(4, txtGanancias.getText());
            ps.setString(5, comboequipo.getItemAt(idc));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(rootPane, "Registro realizado con exito.");
            btnActualizar.setEnabled(false);
            btnEliminar.setEnabled(false);
            btnRegistrar.setEnabled(true);
            limpiarTabla();
            consultar();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Error al tratar de insertar los datos: " + ex);
        }
    }//GEN-LAST:event_btnAgregarActionPerformed
        
        
        
        
        
        
        
        
        
 
    /**
    
           
        try {
            Registrar();
        } catch (SQLException ex) {
            Logger.getLogger(interfaz.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_btnRegistrarActionPerformed
*/ 
    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed

    }//GEN-LAST:event_btnMostrarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(interfaz.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new interfaz().setVisible(true);
            }
        });
    }
//Codigo para consultar
    
    void consultar() {
        String sql = "select * from cliente";

        try {
            conet = conl.getConnection();
            st = conet.createStatement();
            rs = st.executeQuery(sql);
            Object[] jugadores = new Object[5];
            modelo = (DefaultTableModel) Tabla.getModel();
            while (rs.next()) {
                jugadores[0] = rs.getInt(1);
                jugadores[1] = rs.getString(2);
                jugadores[2] = rs.getInt(3);
                jugadores[3] = rs.getInt(4);
                jugadores[4] = rs.getString(5);

                modelo.addRow(jugadores);
            }
            Tabla.setModel(modelo);
        } catch (Exception e) {
        }

    }

     //Codigo para registrar
    
    /**
    
    
    void Registrar() throws SQLException {
        String num = txtnumero.getText();
        String nom = txtnombre.getText();
        String tim = txtTiempo.getText();
        String sal = txtGanancias.getText();
        String bt = comboequipo.getItemAt(idc);

        try {

            if (num.equals("") || nom.equals("") || tim.equals("") || sal.equals("") || bt.equals("")) {
                JOptionPane.showMessageDialog(null, "Falta infresar datos");
                limpiarTabla();
                consultar();

            } else {
                String sql = "insert into jugadores(NUMERO, NOMBRE_Y_APELLIDO,TIEMPO_NBA,GANANCIAS,EQUIPO) values ('" + num + "','" + nom + "','" + tim + "','" + sal + "','" + bt + "',)";
                conet = conl.getConnection();
                st = conet.createStatement();
                st.executeUpdate(sql);
                JOptionPane.showMessageDialog(null, "Nuevo jugador");
                limpiarTabla();
                consultar();
            }
        } catch (Exception e) {
        }
    }
    *  */
    //Codigo para limpiartabla
    
    void limpiarTabla() {
        for (int i = 0; i <= Tabla.getRowCount(); i++) {
            modelo.removeRow(i);
            i = i - 1;

        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Tabla;
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnRegistrar;
    private javax.swing.JComboBox<String> comboequipo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtGanancias;
    private javax.swing.JTextField txtTiempo;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txtnumero;
    // End of variables declaration//GEN-END:variables
}
