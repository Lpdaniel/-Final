package proyecto1;

//Librerias que estamos utilizando
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


//Classe extendida de java.swing
public class Page2 extends javax.swing.JFrame {

    conexion conl = new conexion();
    Connection conet;
    DefaultTableModel modelo;
    Statement st;
    ResultSet rs;
    int idc;

    
    //clase public de la Page2
    public Page2() {
        initComponents();
        setLocationRelativeTo(null);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jFrame1 = new javax.swing.JFrame();
        jComboBox1 = new javax.swing.JComboBox<>();
        content = new javax.swing.JPanel();
        txtnombre = new javax.swing.JTextField();
        txtnumero = new javax.swing.JTextField();
        txtTiempo = new javax.swing.JTextField();
        txtGanancias = new javax.swing.JTextField();
        comboequipo = new javax.swing.JComboBox<>();
        btnActualizar = new javax.swing.JButton();
        btnMostrar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        btnanadir = new javax.swing.JButton();
        btninicio = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        jLabel2.setText("jLabel2");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        content.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtnombre.setBackground(java.awt.Color.black);
        txtnombre.setFont(new java.awt.Font("Century Schoolbook", 1, 18)); // NOI18N
        txtnombre.setForeground(java.awt.Color.white);
        txtnombre.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtnombre.setToolTipText("");
        txtnombre.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, java.awt.Color.white), "Nombre y Apellido", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Century Schoolbook", 1, 14), java.awt.Color.white)); // NOI18N
        content.add(txtnombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 140, 280, 70));

        txtnumero.setBackground(java.awt.Color.black);
        txtnumero.setFont(new java.awt.Font("Century Schoolbook", 1, 18)); // NOI18N
        txtnumero.setForeground(java.awt.Color.white);
        txtnumero.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtnumero.setToolTipText("");
        txtnumero.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, java.awt.Color.white), "N*", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Century Schoolbook", 1, 14), java.awt.Color.white)); // NOI18N
        content.add(txtnumero, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 140, 80, 70));

        txtTiempo.setBackground(java.awt.Color.black);
        txtTiempo.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        txtTiempo.setForeground(java.awt.Color.white);
        txtTiempo.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTiempo.setToolTipText("");
        txtTiempo.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, java.awt.Color.white), "Tiempo en la NBA", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Century Schoolbook", 1, 14), java.awt.Color.white)); // NOI18N
        content.add(txtTiempo, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 220, 370, 70));

        txtGanancias.setBackground(java.awt.Color.black);
        txtGanancias.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        txtGanancias.setForeground(java.awt.Color.white);
        txtGanancias.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtGanancias.setToolTipText("");
        txtGanancias.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, java.awt.Color.white), "Ganancias ", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Century Schoolbook", 1, 18), java.awt.Color.white)); // NOI18N
        txtGanancias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGananciasActionPerformed(evt);
            }
        });
        content.add(txtGanancias, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 300, 370, 70));

        comboequipo.setBackground(java.awt.Color.black);
        comboequipo.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        comboequipo.setForeground(java.awt.Color.white);
        comboequipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Los Angeles Lakers ", "Golden State Warriors", "Minnesota Timberwolves", "Miami Heat", "Dallas Mavericks", "Boston Celtics", "Chicago" }));
        comboequipo.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Equipo", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Century Schoolbook", 1, 14), java.awt.Color.white)); // NOI18N
        comboequipo.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        content.add(comboequipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 380, 260, 80));

        btnActualizar.setBackground(java.awt.Color.black);
        btnActualizar.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        btnActualizar.setForeground(java.awt.Color.white);
        btnActualizar.setText("Actualizar");
        content.add(btnActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 570, 120, 40));

        btnMostrar.setBackground(java.awt.Color.black);
        btnMostrar.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        btnMostrar.setForeground(java.awt.Color.white);
        btnMostrar.setText("Mostrar");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });
        content.add(btnMostrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 570, 120, 40));

        Tabla.setBackground(java.awt.Color.darkGray);
        Tabla.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        Tabla.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        Tabla.setForeground(java.awt.Color.white);
        Tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Numero", "Nombre", "Tiempo", "Ganancias", "Equipo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        Tabla.setAutoscrolls(false);
        Tabla.setEditingColumn(100);
        jScrollPane1.setViewportView(Tabla);

        content.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 140, 540, 420));

        jLabel3.setBackground(java.awt.Color.black);
        jLabel3.setFont(new java.awt.Font("Century Schoolbook", 1, 36)); // NOI18N
        jLabel3.setForeground(java.awt.Color.white);
        jLabel3.setText("Gestion de integrantes");
        content.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 10, -1, -1));

        jButton2.setBackground(java.awt.Color.black);
        jButton2.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        jButton2.setForeground(java.awt.Color.white);
        jButton2.setText("Ingresar");
        content.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 480, 110, 40));

        btnanadir.setBackground(java.awt.Color.darkGray);
        btnanadir.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        btnanadir.setForeground(java.awt.Color.white);
        btnanadir.setText("Añadir");
        btnanadir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnanadirMouseClicked(evt);
            }
        });
        btnanadir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnanadirActionPerformed(evt);
            }
        });
        content.add(btnanadir, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 120, 70));

        btninicio.setBackground(java.awt.Color.black);
        btninicio.setFont(new java.awt.Font("Century Schoolbook", 1, 14)); // NOI18N
        btninicio.setForeground(java.awt.Color.white);
        btninicio.setText("Inicio");
        btninicio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btninicioMouseClicked(evt);
            }
        });
        btninicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btninicioActionPerformed(evt);
            }
        });
        content.add(btninicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 280, 120, 70));

        jLabel1.setBackground(java.awt.Color.black);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/proyecto1/basket.jpg"))); // NOI18N
        jLabel1.setToolTipText("");
        jLabel1.setAlignmentX(0.5F);
        jLabel1.setDisabledIcon(null);
        content.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1160, 770));

        getContentPane().add(content, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //Funciones de los botones    
    private void txtGananciasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGananciasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtGananciasActionPerformed

    private void btnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {                                             
//GEN-FIRST:event_btnAgregarActionPerformed

    }//GEN-LAST:event_btnAgregarActionPerformed
        
    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed

    }//GEN-LAST:event_btnMostrarActionPerformed

    private void btnanadirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnanadirMouseClicked

    }//GEN-LAST:event_btnanadirMouseClicked

    private void btnanadirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnanadirActionPerformed


    }//GEN-LAST:event_btnanadirActionPerformed

    private void btninicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btninicioActionPerformed
      
    }//GEN-LAST:event_btninicioActionPerformed

    private void btninicioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btninicioMouseClicked
    Page1 inter= new Page1();
    inter.setVisible(true);
    this.dispose();

    }//GEN-LAST:event_btninicioMouseClicked
  
    
    


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Tabla;
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnanadir;
    private javax.swing.JButton btninicio;
    private javax.swing.JComboBox<String> comboequipo;
    private javax.swing.JPanel content;
    private javax.swing.JButton jButton2;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtGanancias;
    private javax.swing.JTextField txtTiempo;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txtnumero;
    // End of variables declaration//GEN-END:variables
}
